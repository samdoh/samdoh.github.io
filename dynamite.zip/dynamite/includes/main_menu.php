<?PHP   ?>
                        <div class="eleven column omega tabwrapper">
                            <div class="menu-wrapper">
                                <ul class="tabs menu">
                                    <li>
                                       <a href="index.php" class="active"><span>Home</span></a>
                                       
                                    </li>
                                    <li>
                                       <a href="money.php" class=""><span>Money</span></a>
                                       
                                    </li>
                                    <!-- <li>
                                       <a href="airtime.php" class=""><span>Airtime</span></a>
                                       
                                    </li> -->
                                    <!-- <li>
                                        <a href="index-hosting.php">Web Development & Hosting</a>
                                    </li>
                                     -->
                                    <li>
                                        <a href="#">Our Services</a>
                                        <ul class="child">
                                            <li><a href="#">Software Solution >></a>

                                            <ul class="">
                                            <li><a href="#">SACCO & MFI Software</a></li>
                                            <li><a href="#">School & College System</a></li>
                                            <li><a href="#">HR & Payroll System</a></li>
                                            <li><a href="index-hosting.php">Point of Sale & Inventory Software</a></li>
                                            <li><a href="#">Mobile Applications & USSD</a></li>
                                            <li><a href="#">Bulk SMS Platforms</a></li>
                                            </ul>



                                            </li>
                                            <li><a href="#">Web Design</a></li>
                                            <li><a href="#">Graphics Design</a></li>
                                            <li><a href="index-hosting.php">Domain Registration & Hosting</a></li>
                                            <li><a href="#">Enterprise Networking</a></li>
                                            <li><a href="#">CCTV/IP Camera Installation</a></li>
                                            <li><a href="#">Bulk SMS Platforms</a></li>
                                            <li><a href="#">Desktop Management Services</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="about.php">About Us</a>
                                    </li>
                                    
                                    <!-- <li>
                                        <a href="portfolio-standard-3.html">Projects</a>
                                        <ul class="child">
                                            
                                            <li><a href="portfolio-standard-1.html">Standard 1 Column</a></li>
                                            <li><a href="portfolio-standard-2.html">Standard 2 Columns</a></li>
                                            <li><a href="portfolio-standard-3.html">Standard 3 Columns</a></li>
                                            <li><a href="portfolio-standard-3-alternate.html">Standard 3 Alternate</a></li><li><a href="portfolio-standard-4.html">Standard 4 Columns</a></li>
                                            <li><a href="portfolio-standard-5.html">Standard 5 Columns</a></li>
                                            <li><a href="portfolio-info.html">Info Style</a></li>
                                            <li><a href="portfolio-basic-1.html">Basic Style</a></li>
                                        </ul>
                                    </li> -->
                                    <li>
                                        <a href="contact.php"> Contact-us </a>
                                    </li>
                                </ul>
                          </div>
                        </div>
                    
<?php
?>